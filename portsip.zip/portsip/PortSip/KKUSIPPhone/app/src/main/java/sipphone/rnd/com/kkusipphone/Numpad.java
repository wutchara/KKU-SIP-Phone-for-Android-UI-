package sipphone.rnd.com.kkusipphone;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by linuxham on 21/7/2559.
 */
public class Numpad extends AppCompatActivity {

    protected Button btn0;
    protected Button btn1;
    protected Button btn2;
    protected Button btn3;
    protected Button btn4;
    protected Button btn5;
    protected Button btn6;
    protected Button btn7;
    protected Button btn8;
    protected Button btn9;
    protected Button btn_call;
    protected Button btn_delete;

    protected TextView input_text;

    protected String callOutNumber = "";

    public Numpad() {

    }


}
