package sipphone.rnd.com.kkusipphone;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by linuxham on 21/7/2559.
 */
public class More extends AppCompatActivity {

    protected TextView userName;
    protected TextView userPass;
    protected Button deleteBtn;
    protected Button reloginBtn;

    public More(){}
}
